from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('calculate.urls')),  # Include the app's URLs
    # Add more URL patterns as needed
]
