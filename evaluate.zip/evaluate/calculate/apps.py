from django.apps import AppConfig


class CalculateConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'calculate'
