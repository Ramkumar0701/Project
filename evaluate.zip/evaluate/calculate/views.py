from django.shortcuts import render, HttpResponseRedirect,redirect
from django.http import HttpResponse
from .models import *
import re


def index(request):
    return render(request, 'index.html')

def evaluate(request):
    output_result = ''
    if request.method == 'POST':
        # Handle form submission
        input = request.POST.get('math_expression', '')
        allowed_chars = set('0123456789+- ')
        symbols = r"[!@#$%^*()_/<>?='""]"
        special_characters = re.findall(symbols, input)
        pattern = r'^[1-9]\d*([-+][1-9]\d*)*$'
        
        
        #check the first digit starts with Zero or not
        if input[0] in "0":
            output_result = f"please provide positive number and dont add zero infront of any number"
            return render(request, 'index.html', {'output_result': output_result})
        
        # Check for special characters
        elif special_characters:
            output_result = f"Special characters {special_characters} are not allowed"
            return render(request, 'index.html', {'output_result': output_result})
        
        # Check if the expression starts with an operand
        elif input[0] in '+-':
            output_result = f"the expression should not start or end with operand"
            return render(request, 'index.html', {'output_result':output_result })
        
        # Check if the expression ends with an operand
        elif input[-1] in "+-":
             output_result = f"the expression should not start or end with operand"
             return render(request, 'index.html', {'output_result': output_result})
        
         # Check if the expression contains alphabets   
        elif any(char.isalpha() for char in input):
            return render(request, 'index.html', {'output_result': "Expression should not contain alphabets"})
        
        # Check if the operand is available
        elif not re.search(r'[+-]', input):
              output_result = f"the expression should contain atleast two positive numbers between one operand eg. 1+2"
              return render(request, 'index.html', {'output_result': output_result})
        
        #evaluate
        elif re.match(pattern, input):
                terms = input.split()
                answer = eval(input)
                output_result = f"Answer: {answer}"
                return render(request, 'index.html', {'output_result': output_result})
        

       
        else:
            return render(request, 'index.html', {'output_result': "invalid expression please provide a valid expression"})
    

    else:
        return redirect('\index')            

    # Render the form initially
    