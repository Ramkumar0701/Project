from django.urls import path
from .views import *  # Import your views

urlpatterns = [
    path('',index, name='index'),
    path('evaluate/',evaluate, name='evaluate'),
]
