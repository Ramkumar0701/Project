
// Check if the page is being reloaded
if (performance.navigation.type == 1) {
    clearOutputResult();
}

function clearOutputResult() {
    document.getElementById("output_result").innerText = "";
}        
    